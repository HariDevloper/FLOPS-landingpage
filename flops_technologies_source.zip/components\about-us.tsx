"use client"

import { motion } from "framer-motion"
import { GraduationCap, Users2, Globe2, Sparkles } from "lucide-react"

export function AboutUs() {
  return (
    <section id="about" className="py-24 md:py-32">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 text-balance leading-tight font-heading">
              ABOUT <span className="gradient-text">FLOPS TECHNOLOGIES</span>
            </h2>
            <p className="text-lg text-foreground/90 mb-6 leading-relaxed normal-case">
              <span className="text-white font-semibold">FLOPS Technologies</span> is a team of 6 passionate B.Tech AI & Data Science graduates from India,
              united by a vision to transform businesses through innovative digital solutions.
            </p>
            <p className="text-lg text-foreground/90 mb-6 leading-relaxed normal-case">
              What started as a college project has evolved into a full-fledged tech company. We combine cutting-edge
              technology with creative problem-solving to deliver exceptional results for clients worldwide.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed normal-case">
              Our diverse expertise spans data analysis, technical documentation, full-stack web development, and
              digital marketing - making us your one-stop solution for all digital needs.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="glass rounded-2xl p-6 hover:border-primary/50 transition-all card-hover">
              <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center mb-4">
                <GraduationCap className="w-7 h-7 text-white drop-shadow-[0_0_15px_rgba(59,130,246,0.9)]" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-foreground">B.TECH AI & DS</h3>
              <p className="text-sm text-foreground/80 leading-relaxed normal-case">
                Graduates with expertise in AI and Data Science
              </p>
            </div>

            <div className="glass rounded-2xl p-6 hover:border-secondary/50 transition-all card-hover">
              <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center mb-4">
                <Users2 className="w-7 h-7 text-white drop-shadow-[0_0_15px_rgba(96,165,250,0.9)]" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-foreground">6 TEAM MEMBERS</h3>
              <p className="text-sm text-foreground/80 leading-relaxed normal-case">
                Young, energetic professionals dedicated to excellence
              </p>
            </div>

            <div className="glass rounded-2xl p-6 hover:border-accent/50 transition-all card-hover">
              <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center mb-4">
                <Globe2 className="w-7 h-7 text-white drop-shadow-[0_0_15px_rgba(14,165,233,0.9)]" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-foreground">INDIA-BASED</h3>
              <p className="text-sm text-foreground/80 leading-relaxed normal-case">
                Serving clients globally with local expertise
              </p>
            </div>

            <div className="glass rounded-2xl p-6 hover:border-primary/50 transition-all card-hover">
              <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center mb-4">
                <Sparkles className="w-7 h-7 text-white drop-shadow-[0_0_15px_rgba(59,130,246,0.9)]" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-foreground">INNOVATION FIRST</h3>
              <p className="text-sm text-foreground/80 leading-relaxed normal-case">
                Cutting-edge solutions tailored to your needs
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
