"use client"

import { motion } from "framer-motion"
import { BarChart3, FileCode2, Code2, Megaphone } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const services = [
  {
    icon: BarChart3,
    title: "DATA ANALYSIS",
    description:
      "Transform raw data into actionable insights. We help you make data-driven decisions with advanced analytics and visualization.",
    features: ["Statistical Analysis", "Data Visualization", "Predictive Modeling", "Business Intelligence"],
    color: "primary",
    slug: "data-analysis",
  },
  {
    icon: FileCode2,
    title: "TECHNICAL DOCUMENTATION",
    description:
      "Clear, comprehensive documentation that bridges the gap between complex systems and user understanding.",
    features: ["API Documentation", "User Guides", "Technical Specs", "Knowledge Base"],
    color: "secondary",
    slug: "technical-documentation",
  },
  {
    icon: Code2,
    title: "FULL STACK DEVELOPMENT",
    description:
      "End-to-end web development solutions built with modern technologies, scalable architecture, and best practices.",
    features: ["Web Applications", "Mobile Responsive", "API Development", "Cloud Deployment"],
    color: "accent",
    slug: "full-stack-development",
  },
  {
    icon: Megaphone,
    title: "DIGITAL MARKETING",
    description: "Strategic digital marketing campaigns that boost your online presence and drive measurable results.",
    features: ["SEO Optimization", "Social Media", "Content Strategy", "Analytics & Reporting"],
    color: "primary",
    slug: "digital-marketing",
  },
]

export function Services() {
  return (
    <section id="services" className="py-24 md:py-32 bg-black/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-balance font-heading">
              OUR <span className="gradient-text">SERVICES</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty leading-relaxed normal-case">
              Comprehensive digital solutions tailored to your unique business requirements. We don't just deliver
              projects - we build partnerships.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {services.map((service, index) => (
            <div
              key={service.title}
              className="glass rounded-2xl p-8 hover:border-primary/50 transition-all duration-300 group card-hover"
            >
              <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <service.icon className="w-7 h-7 text-white drop-shadow-[0_0_15px_rgba(59,130,246,0.9)]" />
              </div>
              <h3 className="text-2xl font-bold mb-3 text-foreground">{service.title}</h3>
              <p className="text-muted-foreground mb-6 leading-relaxed normal-case">{service.description}</p>
              <ul className="space-y-2 mb-6">
                {service.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground normal-case">
                    <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
                    {feature}
                  </li>
                ))}
              </ul>
              <a
                href={`/services/${service.slug}`}
                className="block w-full px-4 py-2 rounded-lg glass border border-white/20 text-foreground bg-transparent hover:bg-primary/10 transition-all duration-300 font-medium text-center relative z-10"
                style={{ pointerEvents: 'auto', cursor: 'pointer' }}
              >
                LEARN MORE
              </a>
            </div>
          ))}
        </div>

        <div className="glass rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold mb-3 text-foreground">CUSTOM SOLUTIONS AVAILABLE</h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto leading-relaxed normal-case">
            Don't see what you're looking for? We offer flexible, customized packages based on your specific
            requirements. Let's discuss how we can help bring your vision to life.
          </p>
          <Link href="/contact-form">
            <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90 glow-secondary">
              GET CUSTOM QUOTE
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
