"use client"

import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"
import { useState } from "react"
import Image from "next/image"
import Link from "next/link"

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-[#0a0e27]/80 border-b border-white/10 shadow-lg shadow-primary/5">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <Link href="/" className="flex items-center group">
            <Image src="/logo.png" alt="FLOPS Technologies" width={120} height={120} className="w-30 h-30 scale-[1.9] transition-transform group-hover:scale-[2.1] mt-2" />
          </Link>

          <nav className="hidden md:flex items-center gap-1 absolute left-1/2 -translate-x-1/2 bg-white/5 rounded-full px-6 py-2 border border-white/10">
            <a
              href="/#home"
              className="px-4 py-2 text-sm font-medium text-foreground hover:text-white transition-all rounded-full hover:bg-primary/20 hover:scale-105"
            >
              Home
            </a>
            <a
              href="/#about"
              className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-white transition-all rounded-full hover:bg-primary/20 hover:scale-105"
            >
              About
            </a>
            <a
              href="/#services"
              className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-white transition-all rounded-full hover:bg-primary/20 hover:scale-105"
            >
              Services
            </a>
            <a
              href="/#testimonials"
              className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-white transition-all rounded-full hover:bg-primary/20 hover:scale-105"
            >
              Testimonials
            </a>
            <a
              href="/#contact"
              className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-white transition-all rounded-full hover:bg-primary/20 hover:scale-105"
            >
              Contact
            </a>
          </nav>

          <div className="hidden md:block">
            <Link href="/contact-form">
              <Button className="button-3d text-background font-semibold">Get Started</Button>
            </Link>
          </div>

          <button className="md:hidden text-foreground" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-4 border-t border-white/5">
            <a
              href="/#home"
              className="block text-sm font-medium text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </a>
            <a
              href="/#about"
              className="block text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              About Us
            </a>
            <a
              href="/#services"
              className="block text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Services
            </a>
            <a
              href="/#testimonials"
              className="block text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Testimonials
            </a>
            <a
              href="/#contact"
              className="block text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Contact
            </a>
            <Link href="/contact-form">
              <Button className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90 mt-4">
                Get Started
              </Button>
            </Link>
          </div>
        )}
      </div>
    </header>
  )
}
