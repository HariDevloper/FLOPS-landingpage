"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { motion } from "framer-motion"
import { FileCode2, BookOpen, FileText, GitBranch, Code, Workflow } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const technologies = [
    {
        icon: FileText,
        name: "Markdown & MDX",
        description: "Clean, maintainable documentation with modern markup languages",
    },
    {
        icon: BookOpen,
        name: "Docusaurus & GitBook",
        description: "Professional documentation sites with powerful search and navigation",
    },
    {
        icon: Code,
        name: "Swagger & OpenAPI",
        description: "Interactive API documentation with live testing capabilities",
    },
    {
        icon: GitBranch,
        name: "Git-based Workflows",
        description: "Version-controlled documentation that evolves with your codebase",
    },
    {
        icon: Workflow,
        name: "Confluence & Notion",
        description: "Collaborative documentation platforms for team knowledge sharing",
    },
    {
        icon: FileCode2,
        name: "JSDoc & TypeDoc",
        description: "Automated code documentation generation from source comments",
    },
]

const features = [
    "API Reference Documentation",
    "User Guides & Tutorials",
    "Technical Specifications",
    "Knowledge Base Articles",
    "Developer Onboarding Docs",
    "Release Notes & Changelogs",
]

export default function TechnicalDocumentationPage() {
    return (
        <div className="min-h-screen bg-background">
            <Header />

            <main className="pt-32 pb-20">
                {/* Hero Section */}
                <section className="container mx-auto px-4 mb-20">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                        className="text-center max-w-4xl mx-auto"
                    >
                        <div className="w-20 h-20 rounded-2xl bg-secondary/20 flex items-center justify-center mx-auto mb-6">
                            <FileCode2 className="w-10 h-10 text-white drop-shadow-[0_0_20px_rgba(236,72,153,0.9)]" />
                        </div>
                        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 font-heading">
                            TECHNICAL <span className="gradient-text">DOCUMENTATION</span>
                        </h1>
                        <p className="text-lg md:text-xl text-muted-foreground leading-relaxed normal-case">
                            Clear, comprehensive documentation that bridges the gap between complex systems and user understanding.
                            We create documentation that developers love to read and users find easy to follow.
                        </p>
                    </motion.div>
                </section>

                {/* Technologies Section */}
                <section className="container mx-auto px-4 mb-20">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.2, duration: 0.6 }}
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-heading">
                            TECHNOLOGIES WE <span className="gradient-text">USE</span>
                        </h2>

                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {technologies.map((tech, index) => (
                                <motion.div
                                    key={tech.name}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.1 * index, duration: 0.5 }}
                                    className="glass rounded-2xl p-6 hover:border-secondary/50 transition-all duration-300 group card-hover"
                                >
                                    <div className="w-12 h-12 rounded-xl bg-secondary/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                                        <tech.icon className="w-6 h-6 text-white drop-shadow-[0_0_15px_rgba(236,72,153,0.9)]" />
                                    </div>
                                    <h3 className="text-xl font-bold mb-2 text-foreground">{tech.name}</h3>
                                    <p className="text-muted-foreground text-sm leading-relaxed normal-case">{tech.description}</p>
                                </motion.div>
                            ))}
                        </div>
                    </motion.div>
                </section>

                {/* Features Section */}
                <section className="container mx-auto px-4 mb-20">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.4, duration: 0.6 }}
                        className="glass rounded-2xl p-8 md:p-12"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 font-heading">
                            WHAT WE <span className="gradient-text">DELIVER</span>
                        </h2>
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                            {features.map((feature, index) => (
                                <motion.div
                                    key={feature}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: 0.5 + 0.1 * index, duration: 0.4 }}
                                    className="flex items-center gap-3 p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                                >
                                    <div className="w-2 h-2 rounded-full bg-secondary flex-shrink-0" />
                                    <span className="text-foreground normal-case">{feature}</span>
                                </motion.div>
                            ))}
                        </div>
                    </motion.div>
                </section>

                {/* CTA Section */}
                <section className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.6, duration: 0.6 }}
                        className="glass rounded-2xl p-8 md:p-12 text-center"
                    >
                        <h2 className="text-3xl md:text-4xl font-bold mb-4 font-heading">
                            NEED CRYSTAL-CLEAR <span className="gradient-text">DOCUMENTATION?</span>
                        </h2>
                        <p className="text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed normal-case">
                            Let's create documentation that empowers your users, accelerates developer onboarding,
                            and becomes a valuable asset for your product.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <Link href="/contact-form">
                                <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90 glow-secondary">
                                    GET STARTED
                                </Button>
                            </Link>
                            <Link href="/#services">
                                <Button size="lg" variant="outline" className="glass border-white/20 text-foreground bg-transparent hover:bg-primary/10">
                                    VIEW ALL SERVICES
                                </Button>
                            </Link>
                        </div>
                    </motion.div>
                </section>
            </main>

            <Footer />
        </div>
    )
}
